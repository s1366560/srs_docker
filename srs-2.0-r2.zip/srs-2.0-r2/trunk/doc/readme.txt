ffmpeg-logo.png
ffmpeg-min.png
    ffmpeg的logo。    
source.flv
    avatar预告片，400kbps。
    
aac-iso-13818-7.pdf
    aac标准，aac的编码等。
    
aac-mp4a-format-ISO_IEC_14496-3+2001.pdf
    aac的封装标准，即ts/flv里面的aac raw data标准。
    
amf0_spec_121207.pdf
    adobe amf0标准
    
amf3_spec_121207.pdf
    adobe amf3标准。
    
H.264-AVC-ISO_IEC_14496-10.pdf
    avc标准，编码部分。
    
H.264-AVC-ISO_IEC_14496-10-2012.pdf
    avc标准，编码部分。
    上面的标准是2003年的，和下面的15是2010年的对不上。
    http://www.itu.int/ITU-T/recommendations/rec.aspx?rec=11466
    
H.264-AVC-ISO_IEC_14496-15.pdf
    avc标准，封装部分。
    
H.264_MPEG-4-Part-10-White-Paper.pdf
    h264简介。
    
hls-m3u8-draft-pantos-http-live-streaming-12.txt
    m3u8标准。
    
hls-mpeg-ts-iso13818-1.pdf
    ts标准。
    
hls-mpeg-ts-VB_WhitePaper_TransportStreamVSProgramStream_rd2.pdf
    ts的介绍。
    
rtmp.part1.Chunk-Stream.pdf
rtmp.part2.Message-Formats.pdf
rtmp.part3.Commands-Messages.pdf
rtmp_specification_1.0.pdf
    adobe rtmp标准。
    
rtmfp-rfc7016.pdf
    adobe RTMFP, http://tools.ietf.org/html/rfc7016.
    
rtmfp-tsvarea-1.pdf
    http://www.ietf.org/proceedings/10mar/slides/tsvarea-1.pdf
    
flv_v10_1.pdf
video_file_format_spec_v10_1.pdf
    adobe f4v/flv标准。

HTTP协议：
http1.0-rfc1945.txt
    http://www.rfc-editor.org/rfc/rfc1945.txt
http1.1-rfc2616.txt
    http://www.rfc-editor.org/rfc/rfc2616.txt
arpa-internet-text-messages-rfc822.txt
    http://www.rfc-editor.org/rfc/rfc822.txt

mp3规范：
mp3.id3v2.3.0.pdf
    http://id3.org/id3v2.3.0

Winlin
