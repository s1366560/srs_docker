提供了各种ide。

1. UPP添加Assembly时，路径指向ide即可，譬如：\\dev\winlin\srs\ide

2015.3 winlin
